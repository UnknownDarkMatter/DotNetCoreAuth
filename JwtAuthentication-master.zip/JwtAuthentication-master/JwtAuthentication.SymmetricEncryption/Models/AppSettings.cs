﻿namespace JwtAuthentication.SymmetricEncryption.Models
{
    public class AppSettings
    {
        public string EncryptionKey { get; set; }
    }
}
