﻿namespace JwtAuthentication.Shared.Models
{
    public class UserCredentials
    {
        public string Username { get; set; }
        public string Password { get; set; }
    }
}